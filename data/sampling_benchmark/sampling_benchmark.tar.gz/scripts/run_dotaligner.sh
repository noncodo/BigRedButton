for SIRANGE in 0_55_1 0_55_2 0_55_3 56_65_1 56_65_2 56_65_3
do

  [ ! -f ../results/$SIRANGE ] && mkdir -p ../results/$SIRANGE
  rm -f ../results/$SIRANGE/da.${SIRANGE}.output

  unset families
  unset seen
  declare -A seen

  for FASTA in ../data/$SIRANGE/fastas/*.fasta
  do

    FN=$(basename $FASTA)
    RFAM=${FN%%_*}

    if [ ! "${seen[$RFAM]}" ]
    then
      families+=("$RFAM")
      seen[$RFAM]=1
    fi

    ### get basepair probability matrix with RNAfold ###
    /media/data/phd/projects/DotAligner/bin/getRNAfoldPP.pl $FASTA > ../results/$SIRANGE/${FN}.pp

  done

  echo -e $SIRANGE"\t"${families[@]}

  for RFAM in ${families[@]}
  do

    ### get structure alignment with DotAligner ###
    sequences=( ../results/$SIRANGE/${RFAM}*.pp )
    #echo -e ${sequences[@]}
    LEN=$((${#sequences[@]}-1))
    for i in $(seq 0 $LEN)
    do

      for j in $(seq $((i+1)) $LEN)
      do

	#echo -e ${sequences[$i]}"\t"${sequences[$j]}"\n"
	for TEMP in 0.1 0.25 0.5 0.75 1 5 10;
	do 
	  
	  DAOUT=$(/media/data/sourcecode/c/dotaligner/bin/DotAligner -d ${sequences[$i]} -d ${sequences[$j]} --free-endgaps -T $TEMP -s 1000 -k 0.3 -t 0.5 -o 1 -e 0.05)
	  echo -e "$TEMP 1 "$DAOUT | sed 's/ /\t/g' >> ../results/$SIRANGE/da.${SIRANGE}.output

	  DAOUT=$(/media/data/sourcecode/c/dotaligner/bin/DotAligner -d ${sequences[$i]} -d ${sequences[$j]} -T $TEMP -s 1000 -k 0.3 -t 0.5 -o 1 -e 0.05)
	  echo -e "$TEMP 0 "$DAOUT | sed 's/ /\t/g' >> ../results/$SIRANGE/da.${SIRANGE}.output

	done

      done

    done	
   
  done

done
