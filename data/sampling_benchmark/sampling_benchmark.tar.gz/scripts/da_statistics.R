library(ggplot2)

# Multiple plot function
#
# ggplot objects can be passed in ..., or to plotlist (as a list of ggplot objects)
# - cols:   Number of columns in layout
# - layout: A matrix specifying the layout. If present, 'cols' is ignored.
#
# If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
# then plot 1 will go in the upper left, 2 will go in the upper right, and
# 3 will go all the way across the bottom.
#
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
	library(grid)
    
    	# Make a list from the ... arguments and plotlist
    	plots <- c(list(...), plotlist)
        
        numPlots = length(plots)
        
        # If layout is NULL, then use 'cols' to determine layout
        if (is.null(layout)) {
		# Make the panel
		# ncol: Number of columns of plots
	 	# nrow: Number of rows needed, calculated from # of cols
		layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
		                          ncol = cols, nrow = ceiling(numPlots/cols))
	}
	    
	if (numPlots==1) {
		print(plots[[1]])
	            
	        } else {
			# Set up the page
			grid.newpage()
		        pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
			        
			# Make each plot, in the correct location
		 	for (i in 1:numPlots) {
				# Get the i,j matrix positions of the regions that contain this subplot
				matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
			            
			        print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
	                                    layout.pos.col = matchidx$col))
		}
    	}
}

da.0_55_1 <- read.table("results/0_55_1/da.0_55_1.output")
da.0_55_1 <- as.data.frame(da.0_55_1)
da.0_55_1$V1 <- as.character(da.0_55_1$V1)
da.0_55_1$V10 <- as.character(da.0_55_1$V10)
names(da.0_55_1)[names(da.0_55_1)=="V1"] <- "T"
names(da.0_55_1)[names(da.0_55_1)=="V10"] <- "Sample"
p1 <- ggplot() + geom_density(data=da.0_55_1, aes(x=V9, group=Sample,color=Sample),adjust=2) + xlab("SI") + ylab("Density") + theme_classic() + ggtitle("SI=0-55% Rep. 1")
t1 <- ggplot(da.0_55_1, aes(T,fill=Sample)) + geom_bar(position="fill") + xlab("T (Sampling diversity)") + ylab("Percentage") + ggtitle("SI=0-55% Rep. 1")

da.0_55_2 <- read.table("results/0_55_2/da.0_55_2.output")
da.0_55_2 <- as.data.frame(da.0_55_2)
da.0_55_2$V1 <- as.character(da.0_55_2$V1)
da.0_55_2$V10 <- as.character(da.0_55_2$V10)
names(da.0_55_2)[names(da.0_55_2)=="V1"] <- "T"
names(da.0_55_2)[names(da.0_55_2)=="V10"] <- "Sample"
p2 <- ggplot() + geom_density(data=da.0_55_2, aes(x=V9, group=Sample,color=Sample),adjust=2) + xlab("SI") + ylab("Density") + theme_classic() + ggtitle("SI=0-55% Rep. 2")
t2 <- ggplot(da.0_55_2, aes(T,fill=Sample)) + geom_bar(position="fill") + xlab("T (Sampling diversity)") + ylab("Percentage") + ggtitle("SI=0-55% Rep. 2")

da.0_55_3 <- read.table("results/0_55_3/da.0_55_3.output")
da.0_55_3 <- as.data.frame(da.0_55_3)
da.0_55_3$V1 <- as.character(da.0_55_3$V1)
da.0_55_3$V10 <- as.character(da.0_55_3$V10)
names(da.0_55_3)[names(da.0_55_3)=="V1"] <- "T"
names(da.0_55_3)[names(da.0_55_3)=="V10"] <- "Sample"
p3 <- ggplot() + geom_density(data=da.0_55_3, aes(x=V9, group=Sample,color=Sample),adjust=2) + xlab("SI") + ylab("Density") + theme_classic() + ggtitle("SI=0-55% Rep. 3")
t3 <- ggplot(da.0_55_3, aes(T,fill=Sample)) + geom_bar(position="fill") + xlab("T (Sampling diversity)") + ylab("Percentage") + ggtitle("SI=0-55% Rep. 3")

da.56_65_1 <- read.table("results/56_65_1/da.56_65_1.output")
da.56_65_1 <- as.data.frame(da.56_65_1)
da.56_65_1$V1 <- as.character(da.56_65_1$V1)
da.56_65_1$V10 <- as.character(da.56_65_1$V10)
names(da.56_65_1)[names(da.56_65_1)=="V1"] <- "T"
names(da.56_65_1)[names(da.56_65_1)=="V10"] <- "Sample"
p4 <- ggplot() + geom_density(data=da.56_65_1, aes(x=V9, group=Sample,color=Sample),adjust=2) + xlab("SI") + ylab("Density") + theme_classic() + ggtitle("SI=56-65% Rep. 1")
t4 <- ggplot(da.56_65_1, aes(T,fill=Sample)) + geom_bar(position="fill") + xlab("T (Sampling diversity)") + ylab("Percentage") + ggtitle("SI=56-65% Rep. 1")

da.56_65_2 <- read.table("results/56_65_2/da.56_65_2.output")
da.56_65_2 <- as.data.frame(da.56_65_2)
da.56_65_2$V1 <- as.character(da.56_65_2$V1)
da.56_65_2$V10 <- as.character(da.56_65_2$V10)
names(da.56_65_2)[names(da.56_65_2)=="V1"] <- "T"
names(da.56_65_2)[names(da.56_65_2)=="V10"] <- "Sample"
p5 <- ggplot() + geom_density(data=da.56_65_2, aes(x=V9, group=Sample,color=Sample),adjust=2) + xlab("SI") + ylab("Density") + theme_classic() + ggtitle("SI=56-65% Rep. 2")
t5 <- ggplot(da.56_65_2, aes(T,fill=Sample)) + geom_bar(position="fill") + xlab("T (Sampling diversity)") + ylab("Percentage") + ggtitle("SI=56-65% Rep. 2")

da.56_65_3 <- read.table("results/56_65_3/da.56_65_3.output")
da.56_65_3 <- as.data.frame(da.56_65_3)
da.56_65_3$V1 <- as.character(da.56_65_3$V1)
da.56_65_3$V10 <- as.character(da.56_65_3$V10)
names(da.56_65_3)[names(da.56_65_3)=="V1"] <- "T"
names(da.56_65_3)[names(da.56_65_3)=="V10"] <- "Sample"
p6 <- ggplot() + geom_density(data=da.56_65_3, aes(x=V9, group=Sample,color=Sample),adjust=2) + xlab("SI") + ylab("Density") + theme_classic() + ggtitle("SI=56-65% Rep. 3")
t6 <- ggplot(da.56_65_3, aes(T,fill=Sample)) + geom_bar(position="fill") + xlab("T (Sampling diversity)") + ylab("Percentage") + ggtitle("SI=56-65% Rep. 3")

pdf("results/da_statistics_si.pdf", width=10, height=4)
multiplot(p1, p4, p2, p5, p3, p6, cols=3)
dev.off()

pdf("results/da_statistics_temp.pdf", width=10, height=4)
multiplot(t1, t4, t2, t5, t3, t6, cols=3)
dev.off()

